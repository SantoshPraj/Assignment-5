class Parent {
    public Parent() {
        System.out.println("Parent class constructor invoked");
    }
}

class Child extends Parent {
    public Child() {
        super(); // Invoking parent class constructor
        System.out.println("Child class constructor invoked");
    }
}

public class ConstructorDemo {
    public static void main(String[] args) {
        Child child = new Child();
    }
}
