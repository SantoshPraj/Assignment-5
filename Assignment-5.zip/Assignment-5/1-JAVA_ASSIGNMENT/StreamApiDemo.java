import java.util.ArrayList;
import java.util.List;

public class StreamApiDemo {
    public static void main(String[] args) {
        // Create a large data set
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 1000000; i++) {
            numbers.add(i);
        }

        // Filter even numbers
        List<Integer> evenNumbers = numbers.stream()
                .filter(n -> n % 2 == 0)
                .toList();
        System.out.println("Even Numbers: " + evenNumbers);

        // Filter numbers greater than 500000
        List<Integer> greaterThan500000 = numbers.stream()
                .filter(n -> n > 500000)
                .toList();
        System.out.println("Numbers greater than 500000: " + greaterThan500000);

        // Sort the numbers in descending order
        List<Integer> sortedNumbers = numbers.stream()
                .sorted((a, b) -> b.compareTo(a))
                .toList();
        System.out.println("Sorted Numbers: " + sortedNumbers);
    }
}
