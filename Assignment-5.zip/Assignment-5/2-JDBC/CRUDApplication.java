import java.sql.*;
import java.util.Scanner;

public class CRUDApplication {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/mydatabase"; // Replace "mydatabase" with your database name
        String username = "your_username";
        String password = "your_password";

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Create a connection to the database
            Connection connection = DriverManager.getConnection(url, username, password);

            // Create a statement
            Statement statement = connection.createStatement();

            // Create the table if it doesn't exist
            String createTableQuery = "CREATE TABLE IF NOT EXISTS mytable (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), age INT)";
            statement.execute(createTableQuery);

            Scanner scanner = new Scanner(System.in);

            boolean running = true;
            while (running) {
                System.out.println("CRUD Application Menu:");
                System.out.println("1. Add a record");
                System.out.println("2. View all records");
                System.out.println("3. Update a record");
                System.out.println("4. Delete a record");
                System.out.println("5. Exit");
                System.out.print("Enter your choice (1-5): ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                switch (choice) {
                    case 1:
                        System.out.print("Enter name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter age: ");
                        int age = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline character

                        // Insert a new record into the table
                        String insertQuery = "INSERT INTO mytable (name, age) VALUES (?, ?)";
                        PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
                        insertStatement.setString(1, name);
                        insertStatement.setInt(2, age);
                        insertStatement.executeUpdate();
                        System.out.println("Record added successfully");
                        System.out.println();
                        break;
                    case 2:
                        // Retrieve all records from the table
                        String selectQuery = "SELECT * FROM mytable";
                        ResultSet resultSet = statement.executeQuery(selectQuery);

                        // Display the retrieved data
                        while (resultSet.next()) {
                            int recordId = resultSet.getInt("id");
                            String recordName = resultSet.getString("name");
                            int recordAge = resultSet.getInt("age");

                            System.out.println("ID: " + recordId);
                            System.out.println("Name: " + recordName);
                            System.out.println("Age: " + recordAge);
                            System.out.println();
                        }
                        resultSet.close();
                        break;
                    case 3:
                        System.out.print("Enter the ID of the record to update: ");
                        int recordIdToUpdate = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline character
                        System.out.print("Enter new name: ");
                        String newName = scanner.nextLine();
                        System.out.print("Enter new age: ");
                        int newAge = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline character

                        // Update the record in the table
                        String updateQuery = "UPDATE mytable SET name = ?, age = ? WHERE id = ?";
                        PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
                        updateStatement.setString(1, newName);
                        updateStatement.setInt(2, newAge);
                        updateStatement.setInt(3, recordIdToUpdate);
                        int rowsAffected = updateStatement.executeUpdate();
                        if (rowsAffected > 0) {
                            System.out.println("Record updated successfully");
                        } else {
                            System.out.println("No record found with ID " + recordIdToUpdate);
                        }
                        System.out.println();
                        break;
                    case 4:
                        System.out.print("Enter the ID of the record to delete: ");
                        int recordIdToDelete = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline character

                        // Delete the record from the table
                        String deleteQuery = "DELETE FROM mytable WHERE id = ?";
                        PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery);
                        deleteStatement.setInt(1, recordIdToDelete);
                        int rowsDeleted = deleteStatement.executeUpdate();
                        if (rowsDeleted > 0) {
                            System.out.println("Record deleted successfully");
                        } else {
                            System.out.println("No record found with ID " + recordIdToDelete);
                        }
                        System.out.println();
                        break;
                    case 5:
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        System.out.println();
                        break;
                }
            }

            // Close the resources
            statement.close();
            connection.close();
            scanner.close();
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC driver not found");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Connection to the database failed");
            e.printStackTrace();
        }
    }
}
