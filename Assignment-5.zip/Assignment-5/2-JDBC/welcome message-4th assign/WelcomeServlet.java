import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WelcomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Read the value of the 'name' parameter from the request
        String name = request.getParameter("name");

        // Set the content type of the response
        response.setContentType("text/html");

        // Write the welcome message to the response
        response.getWriter().println("<html>");
        response.getWriter().println("<head><title>Welcome</title></head>");
        response.getWriter().println("<body>");
        response.getWriter().println("<h1>Welcome, " + name + "!</h1>");
        response.getWriter().println("</body>");
        response.getWriter().println("</html>");
    }
}
