import java.sql.*;

public class MySQLConnector {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/mydatabase"; // Replace "mydatabase" with your database name
        String username = "your_username";
        String password = "your_password";

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Create a connection to the database
            Connection connection = DriverManager.getConnection(url, username, password);

            // Create a statement
            Statement statement = connection.createStatement();

            // Define the SQL query
            String query = "SELECT * FROM mytable"; // Replace "mytable" with your table name

            // Execute the query
            ResultSet resultSet = statement.executeQuery(query);

            // Process the result set
            while (resultSet.next()) {
                // Assuming you have columns named "column1" and "column2" in your table
                String column1 = resultSet.getString("column1");
                int column2 = resultSet.getInt("column2");

                // Display the retrieved data
                System.out.println("Column 1: " + column1);
                System.out.println("Column 2: " + column2);
                System.out.println();
            }

            // Close the resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC driver not found");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Connection to the database failed");
            e.printStackTrace();
        }
    }
}
