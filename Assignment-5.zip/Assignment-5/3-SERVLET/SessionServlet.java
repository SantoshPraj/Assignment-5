import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Read the user's name from the request
        String name = request.getParameter("name");

        // Create a session or get the existing session
        HttpSession session = request.getSession();

        // Store the user's name in the session
        session.setAttribute("username", name);

        // Redirect to the home page
        response.sendRedirect("home");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the session
        HttpSession session = request.getSession();

        // Get the user's name from the session
        String name = (String) session.getAttribute("username");

        // Set the content type of the response
        response.setContentType("text/html");

        // Write the welcome message to the response
        response.getWriter().println("<html>");
        response.getWriter().println("<head><title>Welcome</title></head>");
        response.getWriter().println("<body>");
        response.getWriter().println("<h1>Welcome, " + name + "!</h1>");
        response.getWriter().println("<a href=\"logout\">Logout</a>");
        response.getWriter().println("</body>");
        response.getWriter().println("</html>");
    }
}
