@RestController
@RequestMapping("/api")
public class YourController {

    @Autowired
    private YourEntityRepository entityRepository;

    @PostMapping("/your-endpoint")
    public YourEntity createEntity(@RequestBody YourEntity entity) {
        return entityRepository.save(entity);
    }
}
