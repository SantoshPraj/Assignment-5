@Repository
public interface YourEntityRepository extends JpaRepository<YourEntity, Long> {

}
