import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {
   private final ProductRepository productRepository;

   @Autowired
   public ProductController(ProductRepository productRepository) {
      this.productRepository = productRepository;
   }

   @GetMapping
   public List<Product> getAllProducts() {
      return productRepository.findAll();
   }

   @GetMapping("/paged")
   public Page<Product> getAllProductsPaged(
         @RequestParam(defaultValue = "0") int page,
         @RequestParam(defaultValue = "10") int size,
         @RequestParam(defaultValue = "name") String sortBy) {

      PageRequest pageRequest = PageRequest.of(page, size, Sort.by(sortBy));

      return productRepository.findAll(pageRequest);
   }

   @GetMapping("/{id}")
   public Product getProductById(@PathVariable Long id) {
      return productRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Product not found with id: " + id));
   }

   @PostMapping
   public Product createProduct(@RequestBody Product product) {
      return productRepository.save(product);
   }

   @PutMapping("/{id}")
   public Product updateProduct(@PathVariable Long id, @RequestBody Product productDetails) {
      Product product = productRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Product not found with id: " + id));

      product.setName(productDetails.getName());
      product.setDescription(productDetails.getDescription());
      product.setPrice(productDetails.getPrice());

      return productRepository.save(product);
   }

   @DeleteMapping("/{id}")
   public void deleteProduct(@PathVariable Long id) {
      productRepository.deleteById(id);
   }
}
