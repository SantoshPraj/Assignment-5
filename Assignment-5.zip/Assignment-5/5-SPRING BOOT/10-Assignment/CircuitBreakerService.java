import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CircuitBreakerService {
   private final RestTemplate restTemplate;

   public CircuitBreakerService(RestTemplate restTemplate) {
      this.restTemplate = restTemplate;
   }

   @HystrixCommand(fallbackMethod = "fallbackMethod")
   public String callExternalApi() {
      // Call the external REST API using RestTemplate
      String url = "http://api.example.com/api/endpoint";
      return restTemplate.getForObject(url, String.class);
   }

   public String fallbackMethod() {
      // Return a fallback response when the circuit is open or an error occurs
      return "Fallback response";
   }
}
