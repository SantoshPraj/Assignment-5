@Service
public class YourService {

    public void performOperation1(String param1) {
        // Perform operation 1
    }

    public int performOperation2(int param1, int param2) {
        // Perform operation 2
        return param1 + param2;
    }
}
