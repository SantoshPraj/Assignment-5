// Main.java
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Create Hibernate session factory
        SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Employee.class)
                .buildSessionFactory();

        // Create Hibernate session
        Session session = sessionFactory.getCurrentSession();

        try {
            // Begin transaction
            session.beginTransaction();

            // Retrieve all employees
            List<Employee> employees = session.createQuery("from Employee", Employee.class).getResultList();

            // Display employees
            for (Employee employee : employees) {
                System.out.println(employee);
            }

            // Commit transaction
            session.getTransaction().commit();
        } finally {
            // Close session and session factory
            session.close();
            sessionFactory.close();
        }
    }
}
