import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateDemo {
    private static SessionFactory sessionFactory;

    public static void main(String[] args) {
        // Create the Hibernate configuration
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");

        // Create the session factory
        sessionFactory = configuration.buildSessionFactory();

        // Perform update and retrieval operations
        updateAndRetrieveData();
    }

    public static void updateAndRetrieveData() {
        // Open a session from the session factory
        Session session = sessionFactory.openSession();

        try {
            // Begin the transaction
            session.beginTransaction();

            // Update the data in the table
            YourEntity entity = session.get(YourEntity.class, 1L);
            entity.setName("Updated Name");

            // Commit the transaction
            session.getTransaction().commit();

            // Retrieve the updated data
            YourEntity updatedEntity = session.get(YourEntity.class, 1L);

            // Display the updated data on the console
            System.out.println("ID: " + updatedEntity.getId());
            System.out.println("Name: " + updatedEntity.getName());
            // Add more properties to display as needed

        } catch (Exception e) {
            // Handle any exceptions
            e.printStackTrace();
            session.getTransaction().rollback();
        } finally {
            // Close the session
            session.close();
        }
    }
}
