import javax.persistence.*;

@Entity
@Table(name = "your_table_name")
public class YourEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name")
    private String name;

    // Add more properties, getters, and setters as needed

    // Constructor, getters, and setters
    // ...
}
